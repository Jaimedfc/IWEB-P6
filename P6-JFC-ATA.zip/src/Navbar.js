import React from 'react';
export default class Navbar extends React.Component {

	render() {
		return(
			<div key="NavBar" className="NavBar">
				<h1>P6-Quiz en React-Redux por Jaime de Frutos Cerezo y Alexander de la Torre Astanin </h1>
			</div>
			);
	}
}